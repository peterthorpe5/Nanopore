#!/bin/bash
#$ -cwd
cd /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/

conda activate python27
#
#minimap2 -t 50 -ax map-pb Lindley_nanopore_pilon_iter5.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam
#
##grep ">" Lindley_nanopore_pilon_iter5.fasta > names.txt
## cat n.clc.allfinal.out | grep -Ff names.txt > n.clc.allfinal2.out
#
#blastn -task megablast -query Lindley_nanopore_pilon_iter5.fasta -db nt -outfmt '6 qseqid staxids bitscore std scomnames sscinames sblastnames sskingdoms stitle' -evalue 1e-20 -out n.clc.allfinal.out -num_threads 32
#
#blobtools create -i Lindley_nanopore_pilon_iter5.fasta  -s aln.sam -t n.clc.allfinal.out -o Lindley_nanopore_pilon_iter5.fasta.blobplots
# 
# mkdir allfinal.fa.blobplots
# cp Lindley_nanopore_pilon_iter5.fasta.blobplots.blobDB.json ./allfinal.fa.blobplots
# 
#blobtools view -i  Lindley_nanopore_pilon_iter5.fasta.blobplots.blobDB.json -o allfinal.fa.blobplots/
# 
#blobtools blobplot -i Lindley_nanopore_pilon_iter5.fasta.blobplots.blobDB.json -o allfinal.fa.blobplots/ 
#
##rm temp.sam
#
#cd allfinal.fa.blobplots
#cat *.blobDB.table.txt | grep "Streptophyta" | cut -f1 > Streptophyta.names
##cat *.blobDB.table.txt | grep "Arthropoda" | cut -f1 > Arthropoda.names
#cat *.blobDB.table.txt | grep "Ascomycota" | cut -f1 > Ascomycota.names
##cat *.blobDB.table.txt | grep "Chordata" | cut -f1 > Chordata.names
##cat *.blobDB.table.txt | grep "Nematoda" | cut -f1 > Nematoda.names
#cat *.blobDB.table.txt | grep "Basidiomycota" | cut -f1 > Basidiomycota.names
#cat *.blobDB.table.txt | grep "Proteobacteria" | cut -f1 > Proteobacteria.names
#cat *.blobDB.table.txt | grep "Bacteria-undef" | cut -f1 > Bacteria-undef.names
#cat *.blobDB.table.txt | grep "Viruses-undef" | cut -f1 > Viruses-undef.names
##cat *.blobDB.table.txt | grep "Cnidaria" | cut -f1 > Cnidaria.names
#cat *.blobDB.table.txt | grep "Actinobacteria" | cut -f1 > Actinobacteria.names
#cat *.blobDB.table.txt | grep "Mucoromycota" | cut -f1 > Mucoromycota.names
#cat *.blobDB.table.txt | grep "Euryarchaeota" | cut -f1 > Euryarchaeota.names 
#cat *.blobDB.table.txt | grep "Gemmatimonadetes" | cut -f1 > Gemmatimonadetes.names
#cat *.blobDB.table.txt | grep "Bacteroidetes" | cut -f1 > Bacteroidetes.names
#cat *.blobDB.table.txt | awk '$5 < 5' | grep 'no-hit' | sort -k4 -rn | cut -f1 > low_cov_5.LOOKATME
#cat *.names >  bad_contigs.out
#
#cd ../
#
#python ~/misc_python/get_sequences_i_want_from_fasta_command_line_not_wanted_file.py Lindley_nanopore_pilon_iter5.fasta 
#./allfinal.fa.blobplots//bad_contigs.out 10 Lindley_nanop_pilon5X.contim_filtered_final.fasta
#

#####################
# iter 2

#
#minimap2 -t 50 -ax map-pb Lindley_nanop_pilon5X.contim_filtered_final.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam

#grep ">" Lindley_nanopore_pilon_iter5.fasta > names.txt
# cat n.clc.allfinal.out | grep -Ff names.txt > n.clc.allfinal2.out

blastn -task megablast -query Lindley_nanop_pilon5X.contim_filtered_final.fasta -db nt -outfmt '6 qseqid staxids bitscore std scomnames sscinames sblastnames sskingdoms stitle' -evalue 1e-20 -out n.clc.allfinal2.out -num_threads 60


blobtools create -i Lindley_nanop_pilon5X.contim_filtered_final.fasta  -s aln.sam -t n.clc.allfinal2.out -o Lindley_nanop_pilon5X.contim_filtered_final.fasta.blobplots
 
 mkdir allfinal_cont_cleaned.fa.blobplots
 cp Lindley_nanop_pilon5X.contim_filtered_final.fasta.blobplots.blobDB.json ./allfinal_cont_cleaned.fa.blobplots
 
blobtools view -i  Lindley_nanop_pilon5X.contim_filtered_final.fasta.blobplots.blobDB.json -o allfinal_cont_cleaned.fa.blobplots/
 
blobtools blobplot -i Lindley_nanop_pilon5X.contim_filtered_final.fasta.blobplots.blobDB.json -o allfinal_cont_cleaned.fa.blobplots/ 

#rm temp.sam

cd allfinal_cont_cleaned.fa.blobplots
cat *.blobDB.table.txt | grep "Streptophyta" | cut -f1 > Streptophyta.names
#cat *.blobDB.table.txt | grep "Arthropoda" | cut -f1 > Arthropoda.names
cat *.blobDB.table.txt | grep "Ascomycota" | cut -f1 > Ascomycota.names
#cat *.blobDB.table.txt | grep "Chordata" | cut -f1 > Chordata.names
#cat *.blobDB.table.txt | grep "Nematoda" | cut -f1 > Nematoda.names
cat *.blobDB.table.txt | grep "Basidiomycota" | cut -f1 > Basidiomycota.names
cat *.blobDB.table.txt | grep "Proteobacteria" | cut -f1 > Proteobacteria.names
cat *.blobDB.table.txt | grep "Bacteria-undef" | cut -f1 > Bacteria-undef.names
cat *.blobDB.table.txt | grep "Viruses-undef" | cut -f1 > Viruses-undef.names
#cat *.blobDB.table.txt | grep "Cnidaria" | cut -f1 > Cnidaria.names
cat *.blobDB.table.txt | grep "Actinobacteria" | cut -f1 > Actinobacteria.names
cat *.blobDB.table.txt | grep "Mucoromycota" | cut -f1 > Mucoromycota.names
cat *.blobDB.table.txt | grep "Euryarchaeota" | cut -f1 > Euryarchaeota.names 
cat *.blobDB.table.txt | grep "Gemmatimonadetes" | cut -f1 > Gemmatimonadetes.names
cat *.blobDB.table.txt | grep "Bacteroidetes" | cut -f1 > Bacteroidetes.names
cat *.blobDB.table.txt | awk '$5 < 5' | grep 'no-hit' | sort -k4 -rn | cut -f1 > low_cov_5.LOOKATME
cat *.names >  bad_contigs.out

cd ../







