
cd  /storage/home/users/pjt6/project/Lindley_RNAseq_mapping/nanopore_genome/genes
python /storage/home/users/pjt6/misc_python/BLAST_output_parsing/Blast_RBH_two_fasta_file_evalue.py --threads 32 -o  Gpal_Lindley-nanopore_intron_hints.aa_VS_newton.RBBH.tab Gpal_Lindley-nanopore_intron_hints.aa /storage/home/users/pjt6/newton/comparative_genomics/all_nems/Gpal_newton_newton.proteins.fa
