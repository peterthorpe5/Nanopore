#!/bin/bash
#$ -cwd
set -e

cd /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic


#11) POLISHING. Not yet achived. The default approach (a different mapper will be chosen due to the slow run time of BLASR)
#https:/flowersoftheocean.wordpress.com/2018/04/16/polishing-pacbio-assemblies-with-arrow-and-pilon/
# blasr , although slow has some good option, such as seed. Alignment lenght etc ... see below. This takes weeks to run. 
# Polishing needs to be repeated 3 or more time, this adding months onto assembly-process time.

#conda activate pb_toolkit

#conda activate pilon1.23


THREADS=50
PREFIX=scaffolds_gapfilled_FINAL.fasta


############################################################################################################################################################
# pilon Illumina polishing-pacbio-assemblies-with-arrow-and-pilon/

##############################################################
##################################################
# pilon 1



PILITERNUM=1

#minimap2 -t $THREADS -ax map-pb scaffolds_gapfilled_FINAL.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq > aln.sam
#samtools view -@ $THREADS -S -b -o alnunsorted.bam aln.sam
#wait
#samtools sort -@ $THREADS -o  sorted_mini2.bam alnunsorted.bam
#samtools index sorted_mini2.bam
#
#bwa index scaffolds_gapfilled_FINAL.fasta
#bwa mem -t $THREADS scaffolds_gapfilled_FINAL.fasta /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R1_paired_prinseq_good_NNgn.fastq /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R2_paired_prinseq_good_86d2.fastq > new.illumina.mapped.sam
#
#samtools view -@ $THREADS -S -b -o new.illumina.temp.mapped.bam new.illumina.mapped.sam
#samtools sort -@ $THREADS -o  new.illumina.mapped.bam new.illumina.temp.mapped.bam
#rm new.illumina.temp.mapped.bam new.illumina.mapped.sam
#samtools index new.illumina.mapped.bam
#
## this has been through one iteration. Now use the ouptu from iteration 1 for the new error correction. 
## old way = java -Xmx235G -jar ~/scratch/Downloads/pilon-1.22.jar
#pilon --genome scaffolds_gapfilled_FINAL.fasta --bam new.illumina.mapped.bam --pacbio sorted_mini2.bam --changes --vcf --diploid --threads $THREADS --output Lindley_nanopore_pilon_iter1

#
###################################################
## pilon 2
#
#PILITERNUM=2
#
#minimap2 -t $THREADS -ax map-pb Lindley_nanopore_pilon_iter1.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam
#samtools view -@ $THREADS -S -b -o alnunsorted.bam aln.sam
#wait
#samtools sort -@ $THREADS -o  sorted_mini2.bam alnunsorted.bam
#samtools index sorted_mini2.bam
#
#bwa index Lindley_nanopore_pilon_iter1.fasta
#bwa mem -t $THREADS Lindley_nanopore_pilon_iter1.fasta /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R1_paired_prinseq_good_NNgn.fastq /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R2_paired_prinseq_good_86d2.fastq > new.illumina.mapped.sam
#
#samtools view -@ $THREADS -S -b -o new.illumina.temp.mapped.bam new.illumina.mapped.sam
#samtools sort -@ $THREADS -o  new.illumina.mapped.bam new.illumina.temp.mapped.bam
#
#samtools index new.illumina.mapped.bam
#rm new.illumina.temp.mapped.bam new.illumina.mapped.sam
#
## this has been through one iteration. Now use the ouptu from iteration 1 for the new error correction. 
#pilon --genome Lindley_nanopore_pilon_iter1.fasta --bam new.illumina.mapped.bam --pacbio sorted_mini2.bam --changes --vcf --diploid --threads $THREADS --output Lindley_nanopore_pilon_iter2
#
#
###################################################
## pilon 3
#
#PILITERNUM=3
#
#minimap2 -t $THREADS -ax map-pb Lindley_nanopore_pilon_iter2.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam
#samtools view -@ $THREADS -S -b -o alnunsorted.bam aln.sam
#wait
#samtools sort -@ $THREADS -o  sorted_mini2.bam alnunsorted.bam
#samtools index sorted_mini2.bam
#bwa index Lindley_nanopore_pilon_iter2.fasta
#bwa mem -t $THREADS Lindley_nanopore_pilon_iter2.fasta /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R1_paired_prinseq_good_NNgn.fastq /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R2_paired_prinseq_good_86d2.fastq > new.illumina.mapped.sam
#
#samtools view -@ $THREADS -S -b -o new.illumina.temp.mapped.bam new.illumina.mapped.sam
#samtools sort -@ $THREADS -o  new.illumina.mapped.bam new.illumina.temp.mapped.bam
#samtools index new.illumina.mapped.bam
#rm new.illumina.temp.mapped.bam new.illumina.mapped.sam
#
## this has been through one iteration. Now use the ouptu from iteration 1 for the new error correction. 
#pilon --genome Lindley_nanopore_pilon_iter2.fasta --bam new.illumina.mapped.bam --pacbio sorted_mini2.bam --changes --vcf --diploid --threads $THREADS --output Lindley_nanopore_pilon_iter3
#
#
#
###################################################
#PILITERNUM=4
#
#minimap2 -t $THREADS -ax map-pb Lindley_nanopore_pilon_iter3.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam
#samtools view -@ $THREADS -S -b -o alnunsorted.bam aln.sam
#wait
#samtools sort -@ $THREADS -o  sorted_mini2.bam alnunsorted.bam
#samtools index sorted_mini2.bam
#
#bwa index Lindley_nanopore_pilon_iter3.fasta
#bwa mem -t $THREADS Lindley_nanopore_pilon_iter3.fasta /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R1_paired_prinseq_good_NNgn.fastq /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R2_paired_prinseq_good_86d2.fastq > new.illumina.mapped.sam
#
#samtools view -@ $THREADS -S -b -o new.illumina.temp.mapped.bam new.illumina.mapped.sam
#samtools sort -@ $THREADS -o  new.illumina.mapped.bam new.illumina.temp.mapped.bam
#samtools index new.illumina.mapped.bam
#
#rm new.illumina.temp.mapped.bam new.illumina.mapped.sam
#
## this has been through one iteration. Now use the ouptu from iteration 1 for the new error correction. 
#pilon --genome Lindley_nanopore_pilon_iter3.fasta --bam new.illumina.mapped.bam --pacbio sorted_mini2.bam --changes --vcf --diploid --threads $THREADS --output Lindley_nanopore_pilon_iter4
#
##################################################
#PILITERNUM=5
#
#minimap2 -t $THREADS -ax map-pb Lindley_nanopore_pilon_iter4.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam
#samtools view -@ $THREADS -S -b -o alnunsorted.bam aln.sam
#wait
#samtools sort -@ $THREADS -o  sorted_mini2.bam alnunsorted.bam
#samtools index sorted_mini2.bam

bwa index Lindley_nanopore_pilon_iter4.fasta
bwa mem -t $THREADS Lindley_nanopore_pilon_iter4.fasta /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R1_paired_prinseq_good_NNgn.fastq /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R2_paired_prinseq_good_86d2.fastq > new.illumina.mapped.sam

samtools view -@ $THREADS -S -b -o new.illumina.temp.mapped.bam new.illumina.mapped.sam
samtools sort -@ $THREADS -o  new.illumina.mapped.bam new.illumina.temp.mapped.bam

samtools index new.illumina.mapped.bam
rm new.illumina.temp.mapped.bam new.illumina.mapped.sam

# this has been through one iteration. Now use the ouptu from iteration 1 for the new error correction. 
pilon --genome Lindley_nanopore_pilon_iter4.fasta --bam new.illumina.mapped.bam --pacbio sorted_mini2.bam --changes --vcf --diploid --threads $THREADS --output Lindley_nanopore_pilon_iter5

##################################################
#PILITERNUM=6
#
#minimap2 -t $THREADS -ax map-pb Lindley_nanopore_pilon_iter5.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln.sam
#samtools view -@ $THREADS -S -b -o alnunsorted.bam aln.sam
#wait
#samtools sort -@ $THREADS -o  sorted_mini2.bam alnunsorted.bam
#samtools index sorted_mini2.bam
#
#bwa index Lindley_nanopore_pilon_iter5.fasta
#bwa mem -t $THREADS Lindley_nanopore_pilon_iter5.fasta /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R1_paired_prinseq_good_NNgn.fastq /storage/home/users/pjt6/project/20180930_Gpallida_newton_genome/GPAL_Lindley/R2_paired_prinseq_good_86d2.fastq > new.illumina.mapped.sam
#
#samtools view -@ $THREADS -S -b -o new.illumina.temp.mapped.bam new.illumina.mapped.sam
#samtools sort -@ $THREADS -o  new.illumina.mapped.bam new.illumina.temp.mapped.bam
#samtools index new.illumina.mapped.bam
#
#rm new.illumina.temp.mapped.bam new.illumina.mapped.sam
#
## this has been through one iteration. Now use the ouptu from iteration 1 for the new error correction. 
#pilon --genome Lindley_nanopore_pilon_iter5.fasta --bam new.illumina.mapped.bam --pacbio sorted_mini2.bam --changes --vcf --diploid --threads $THREADS --output Lindley_nanopore_pilon_iter6
#
#

#################################################
# Haplotype phasing
##################################################
PILITERNUM=7

#conda activate haplo_phase
#
#minimap2 -t $THREADS -ax map-pb Lindley_nanopore_pilon_iter5.fasta /storage/home/users/pjt6/project/20200817_Lindley_nanopore_genomic/Mt_unmapped_reads_lindley_nanopore_samtools.fastq  > aln2.sam
#samtools view -@ $THREADS -S -b -o alnunsorted2.bam aln2.sam
wait
#samtools sort -@ $THREADS -o  sorted_mini3.bam alnunsorted2.bam
#samtools index sorted_mini3.bam

